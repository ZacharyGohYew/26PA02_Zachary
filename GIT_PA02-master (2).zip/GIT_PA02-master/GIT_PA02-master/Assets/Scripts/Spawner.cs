﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{

    public GameObject walrus;
    public GameObject ice;
    public GameObject barrel;
    public GameObject tire;


    private float timer;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        timer += Time.deltaTime;

        float randomnum = Random.Range(0, 3);

        float randomx = Random.Range(-10, 8);

        Vector3 spawnpos = new Vector3(Random.Range(-1.5f, 1.5f), 0, 47);

        if(timer >= 1)
        {
            timer = 0;
            if (randomnum == 0)
            {
                Instantiate(walrus, spawnpos, Quaternion.identity);
            }
            if (randomnum == 1)
            {
                Instantiate(ice, spawnpos, Quaternion.identity);

            }
            if (randomnum == 2)
            {
                Instantiate(barrel, spawnpos, Quaternion.identity);

            }
            if (randomnum == 3)
            {
                Instantiate(tire, spawnpos, Quaternion.identity);

            }

        }


    }
}
